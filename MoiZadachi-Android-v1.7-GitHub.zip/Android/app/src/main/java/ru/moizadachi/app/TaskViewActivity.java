package ru.moizadachi.app;
import android.app.*;
import android.content.*;
import android.os.Bundle;
import android.graphics.*;import android.net.Uri;import android.view.*;import java.io.*;
import android.widget.*;
import java.text.*;
import java.util.*;
public class TaskViewActivity extends Activity {
 private TaskDb db;
 public void onCreate(Bundle b){ThemeUtil.apply(this);super.onCreate(b);db=new TaskDb(this);}
 protected void onResume(){super.onResume();draw();}
 private void draw(){
  Task t=db.get(getIntent().getLongExtra("id",0));if(t==null){finish();return;}
  LinearLayout root=Ui.column(this),bar=new LinearLayout(this);Button back=Ui.button(this,"‹ Назад");back.setOnClickListener(v->finish());bar.addView(back,new LinearLayout.LayoutParams(0,-2,1));Button edit=Ui.button(this,"Редактировать");edit.setOnClickListener(v->startActivity(new Intent(this,EditTaskActivity.class).putExtra("id",t.id)));bar.addView(edit,new LinearLayout.LayoutParams(0,-2,1));root.addView(bar);
  ScrollView scroll=new ScrollView(this);LinearLayout content=Ui.column(this);content.setPadding(0,Ui.dp(this,24),0,Ui.dp(this,24));TextView title=Ui.text(this,t.title,28);title.setTypeface(null,1);title.setTextIsSelectable(true);content.addView(title);
  if(t.dueAt>0){TextView date=Ui.text(this,new SimpleDateFormat("d MMMM yyyy, HH:mm",new Locale("ru")).format(new Date(t.dueAt)),16);date.setPadding(0,Ui.dp(this,16),0,0);content.addView(date);}
  if(t.note!=null&&!t.note.isEmpty()){TextView note=Ui.text(this,t.note,19);note.setTextIsSelectable(true);note.setPadding(0,Ui.dp(this,24),0,0);content.addView(note);}
  java.util.List<String> localPhotos=PhotoCodec.decode(t.photoUri);java.util.List<String> cloudPhotos=PhotoCodec.decode(t.photoPath);if(!localPhotos.isEmpty()){TextView ph=Ui.text(this,"Фотографии · "+localPhotos.size(),16);ph.setPadding(0,Ui.dp(this,20),0,Ui.dp(this,8));content.addView(ph);HorizontalScrollView hs=new HorizontalScrollView(this);LinearLayout gallery=new LinearLayout(this);gallery.setOrientation(LinearLayout.HORIZONTAL);hs.addView(gallery);content.addView(hs);for(String u:localPhotos){final String uri=u;ImageView thumb=new ImageView(this);thumb.setScaleType(ImageView.ScaleType.CENTER_CROP);thumb.setContentDescription("Открыть фото");thumb.setOnClickListener(v->Ui.openPhoto(this,uri));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(Ui.dp(this,150),Ui.dp(this,150));lp.setMargins(0,0,Ui.dp(this,8),0);gallery.addView(thumb,lp);loadThumb(thumb,uri);}}else if(!cloudPhotos.isEmpty())content.addView(Ui.text(this,"Фотографии загрузятся после синхронизации",15));
  scroll.addView(content);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));Ui.install(this,root);
 }
 private void loadThumb(ImageView view,String raw){new Thread(()->{try{Uri uri=Uri.parse(raw);BitmapFactory.Options o=new BitmapFactory.Options();o.inJustDecodeBounds=true;try(InputStream in=getContentResolver().openInputStream(uri)){BitmapFactory.decodeStream(in,null,o);}int target=900;o.inSampleSize=Math.max(1,Math.max(o.outWidth,o.outHeight)/target);o.inJustDecodeBounds=false;Bitmap bmp;try(InputStream in=getContentResolver().openInputStream(uri)){bmp=BitmapFactory.decodeStream(in,null,o);}if(bmp!=null)runOnUiThread(()->view.setImageBitmap(bmp));}catch(Exception ignored){}}).start();}
}
