package ru.moizadachi.app;
import android.content.*;
import android.net.Uri;
import java.net.*;
import java.io.*;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;
import org.json.*;
final class CloudSync {
 static final AtomicBoolean BUSY=new AtomicBoolean();
 static volatile String status="";
 static class ApiError extends IOException {final int code;ApiError(int c,String s){super(s);code=c;}}
 static byte[] requestBytes(String method,String path,String token,byte[] data,String type,String prefer) throws Exception {
  HttpURLConnection c=(HttpURLConnection)new URL(CloudAuth.URL+path).openConnection();c.setConnectTimeout(15000);c.setReadTimeout(25000);c.setRequestMethod(method);c.setRequestProperty("apikey",CloudAuth.KEY);if(token!=null)c.setRequestProperty("Authorization","Bearer "+token);if(prefer!=null)c.setRequestProperty("Prefer",prefer);if(data!=null){c.setDoOutput(true);c.setRequestProperty("Content-Type",type);c.setFixedLengthStreamingMode(data.length);try(OutputStream o=c.getOutputStream()){o.write(data);}}
  int code=c.getResponseCode();InputStream stream=code<400?c.getInputStream():c.getErrorStream();byte[] bytes=read(stream,22*1024*1024);c.disconnect();if(code>=400){String raw=new String(bytes,"UTF-8");String message;try{JSONObject e=new JSONObject(raw);message=e.optString("msg",e.optString("message",e.optString("error_description","Ошибка облака")));}catch(Exception e){message="Ошибка облака";}throw new ApiError(code,translate(message,code));}return bytes;
 }
 static String request(String m,String p,String t,byte[] b,String ct,String prefer)throws Exception{return new String(requestBytes(m,p,t,b,ct,prefer),"UTF-8");}
 static byte[] read(InputStream in,int limit)throws Exception {if(in==null)return new byte[0];try(InputStream s=in;ByteArrayOutputStream out=new ByteArrayOutputStream()){byte[] b=new byte[8192];int n;while((n=s.read(b))!=-1){if(out.size()+n>limit)throw new IOException("Файл слишком большой (максимум 20 МБ)");out.write(b,0,n);}return out.toByteArray();}}
 static String translate(String s,int code){String l=s.toLowerCase(Locale.ROOT);if(l.contains("invalid login"))return "Неверная почта или пароль";if(l.contains("email not confirmed"))return "Подтвердите почту по ссылке из письма";if(l.contains("email address not authorized"))return "Supabase пока разрешает письма только владельцу проекта. Используйте почту владельца или настройте почтовый сервис.";if(code==429)return "Слишком много попыток. Попробуйте позже.";if(code==401)return "Сеанс закончился. Войдите заново; задачи сохранены.";if(code==403)return "Доступ запрещён. Проверьте правила облака.";return s;}
 static String friendly(Exception e){if(e instanceof UnknownHostException||e instanceof SocketTimeoutException||e instanceof ConnectException)return "Нет связи с облаком. Изменения сохранены на устройстве.";return e.getMessage()==null?"Не удалось подключиться. Изменения сохранены.":e.getMessage();}
 static String iso(long n){return n==0?null:Instant.ofEpochMilli(n).toString();}
 static long ms(String s){return s==null||s.isEmpty()?0:Instant.parse(s).toEpochMilli();}
 static String nullable(JSONObject j,String k){return j.isNull(k)?null:j.optString(k,null);}
 static Task fromRemote(JSONObject r)throws Exception{Task t=new Task();t.uuid=r.getString("id");t.owner=r.getString("owner_id");t.title=r.getString("title");t.note=r.optString("note","");t.category=r.getString("category");t.dueAt=ms(nullable(r,"due_at"));t.remindBefore=r.optLong("remind_before_ms");t.done=r.optBoolean("done");t.photoPath=nullable(r,"photo_path");t.deleted=nullable(r,"deleted_at")!=null;t.serverVersion=r.getLong("version");t.dirty=false;return t;}
 static JSONObject payload(Task t,String photo)throws Exception{return new JSONObject().put("id",t.uuid).put("owner_id",t.owner).put("title",t.title).put("note",t.note).put("category",t.category).put("due_at",t.dueAt==0?JSONObject.NULL:iso(t.dueAt)).put("remind_before_ms",t.remindBefore).put("done",t.done).put("photo_path",photo==null?JSONObject.NULL:photo).put("deleted_at",t.deleted?Instant.now().toString():JSONObject.NULL);}
 static boolean same(Task a,JSONObject r,String photo)throws Exception{Task b=fromRemote(r);return a.title.equals(b.title)&&a.note.equals(b.note)&&a.category.equals(b.category)&&a.dueAt==b.dueAt&&a.remindBefore==b.remindBefore&&a.done==b.done&&a.deleted==b.deleted&&Objects.equals(photo,b.photoPath);}
 static JSONObject remote(String id,String token)throws Exception{JSONArray a=new JSONArray(request("GET","/rest/v1/mz_tasks?id=eq."+id+"&select=*",token,null,null,null));return a.length()==0?null:a.getJSONObject(0);}
 static void run(Context ctx){Context c=ctx.getApplicationContext();if(CloudAuth.owner(c).isEmpty()||!BUSY.compareAndSet(false,true))return;
  status="Синхронизация…";String user=CloudAuth.owner(c);
  try(TaskDb db=new TaskDb(c)){
   String token=CloudAuth.token(c);
   for(Task t:db.dirty(user)){
    if(!CloudAuth.owner(c).equals(user))return;
    String photo=t.photoPath;
    if(t.photoDirty){java.util.List<String> uris=PhotoCodec.decode(t.photoUri);java.util.ArrayList<String> paths=new java.util.ArrayList<>();for(int pi=0;pi<uris.size();pi++){String one=uris.get(pi);String mime=c.getContentResolver().getType(Uri.parse(one));if(mime==null)mime="image/jpeg";byte[] data=read(c.getContentResolver().openInputStream(Uri.parse(one)),20*1024*1024);StringBuilder hash=new StringBuilder();for(byte b:java.security.MessageDigest.getInstance("SHA-256").digest(data))hash.append(String.format(Locale.ROOT,"%02x",b&255));String path=user+"/"+t.uuid+"-"+pi+"-"+hash;try{request("POST","/storage/v1/object/mz-photos/"+path,token,data,mime,null);}catch(ApiError e){if(e.code!=409&&!(e.code==400&&e.getMessage().toLowerCase(Locale.ROOT).contains("already exists")))throw e;}paths.add(path);}photo=PhotoCodec.encode(paths);}
    JSONObject r=remote(t.uuid,token);
    if(r!=null&&same(t,r,photo)){db.acknowledge(t,r,photo);continue;}
    if(r!=null&&r.getLong("version")!=t.serverVersion){db.resolveConflict(t,r,user);continue;}
    JSONObject body=payload(t,photo);JSONArray response;
    if(r==null){response=new JSONArray(request("POST","/rest/v1/mz_tasks?select=*",token,body.toString().getBytes("UTF-8"),"application/json","return=representation"));}
    else{body.put("version",t.serverVersion);response=new JSONArray(request("PATCH","/rest/v1/mz_tasks?id=eq."+t.uuid+"&version=eq."+t.serverVersion+"&select=*",token,body.toString().getBytes("UTF-8"),"application/json","return=representation"));}
    if(response.length()>0)db.acknowledge(t,response.getJSONObject(0),photo);
   }
   for(int offset=0;;offset+=200){if(!CloudAuth.owner(c).equals(user))return;JSONArray rows=new JSONArray(request("GET","/rest/v1/mz_tasks?owner_id=eq."+user+"&select=*&order=id.asc&limit=200&offset="+offset,token,null,null,null));for(int i=0;i<rows.length();i++)db.receive(rows.getJSONObject(i),user);if(rows.length()<200)break;}
   for(Task t:db.list("owner=?",new String[]{user},"id")){if(t.deleted)ReminderScheduler.cancel(c,t.id);else ReminderScheduler.schedule(c,t);}
   for(Task t:db.all()){
    if(!CloudAuth.owner(c).equals(user))return;
    if(t.photoPath!=null&&t.photoUri==null&&!t.photoDirty){File dir=new File(c.getFilesDir(),"cloud-photos");dir.mkdirs();java.util.ArrayList<String> localUris=new java.util.ArrayList<>();for(String onePath:PhotoCodec.decode(t.photoPath)){File f=new File(dir,UUID.nameUUIDFromBytes(onePath.getBytes("UTF-8"))+".img");if(!f.exists()){byte[] data=requestBytes("GET","/storage/v1/object/authenticated/mz-photos/"+onePath,token,null,null,null);File temp=new File(dir,f.getName()+".tmp");try(FileOutputStream out=new FileOutputStream(temp)){out.write(data);out.getFD().sync();}if(!temp.renameTo(f))throw new IOException("Не удалось сохранить фото");}localUris.add(Uri.fromFile(f).toString());}db.cachePhoto(t.uuid,t.photoPath,PhotoCodec.encode(localUris));}
   }
   for(Task t:db.list("owner=?",new String[]{user},"id")){if(t.deleted)ReminderScheduler.cancel(c,t.id);else ReminderScheduler.schedule(c,t);}
   CloudAuth.prefs(c).edit().putLong("last_sync",System.currentTimeMillis()).apply();status=db.pending()>0?"Остались изменения для отправки":"Синхронизировано";
  }catch(Exception e){status=friendly(e);}finally{BUSY.set(false);CloudAuth.prefs(c).edit().putString("status",status).apply();c.sendBroadcast(new Intent(c.getPackageName()+".SYNC").setPackage(c.getPackageName()));}
 }
}
