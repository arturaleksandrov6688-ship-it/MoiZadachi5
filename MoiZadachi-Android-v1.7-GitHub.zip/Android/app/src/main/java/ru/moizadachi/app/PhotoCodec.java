package ru.moizadachi.app;
import java.util.*;import org.json.*;
final class PhotoCodec {
 static final int MAX=10;
 static List<String> decode(String raw){ArrayList<String> out=new ArrayList<>();if(raw==null||raw.trim().isEmpty())return out;try{if(raw.trim().startsWith("[")){JSONArray a=new JSONArray(raw);for(int i=0;i<a.length()&&out.size()<MAX;i++){String s=a.optString(i,null);if(s!=null&&!s.isEmpty())out.add(s);}return out;}}catch(Exception ignored){}out.add(raw);return out;}
 static String encode(List<String> list){if(list==null||list.isEmpty())return null;if(list.size()==1)return list.get(0);JSONArray a=new JSONArray();for(int i=0;i<list.size()&&i<MAX;i++)a.put(list.get(i));return a.toString();}
}
