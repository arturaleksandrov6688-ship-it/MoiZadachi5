#!/usr/bin/env bash
set -euo pipefail
# Offline-capable Android build using the official SDK, no Gradle download required.
project_dir="$(cd "$(dirname "$0")/.." && pwd)"
sdk_dir="${ANDROID_HOME:?Set ANDROID_HOME to the Android SDK}"
jdk_dir="${JAVA_HOME:?Set JAVA_HOME to a JDK 17 or newer}"
build_dir="$project_dir/build-manual"
sdk_tools="$sdk_dir/build-tools/35.0.0"
android_jar="$sdk_dir/platforms/android-35/android.jar"
mkdir -p "$build_dir/gen" "$build_dir/classes" "$build_dir/dex"
cp "$project_dir/tools/AndroidManifest-build.xml" "$build_dir/AndroidManifest.xml"
"$sdk_tools/aapt" package -f -M "$build_dir/AndroidManifest.xml" \
  -S "$project_dir/app/src/main/res" -I "$android_jar" -J "$build_dir/gen" \
  --custom-package ru.moizadachi.app \
  --min-sdk-version 26 --target-sdk-version 35 --version-code 6 --version-name 1.5 \
  -F "$build_dir/resources.apk"
mapfile -t source_files < <(find "$project_dir/app/src/main/java" "$build_dir/gen" -name '*.java')
"$jdk_dir/bin/javac" -encoding UTF-8 -source 8 -target 8 -bootclasspath "$android_jar:$sdk_tools/core-lambda-stubs.jar" \
  -d "$build_dir/classes" "${source_files[@]}"
mapfile -t class_files < <(find "$build_dir/classes" -name '*.class')
"$sdk_tools/d8" --lib "$android_jar" --min-api 26 --output "$build_dir/dex" "${class_files[@]}"
cp "$build_dir/resources.apk" "$build_dir/unsigned.apk"
(cd "$build_dir/dex" && zip -q -j "$build_dir/unsigned.apk" classes*.dex)
"$sdk_tools/zipalign" -f 4 "$build_dir/unsigned.apk" "$build_dir/aligned.apk"
if [ ! -f "$project_dir/tools/debug.keystore" ]; then
  "$jdk_dir/bin/keytool" -genkeypair -keystore "$project_dir/tools/debug.keystore" \
    -storepass android -keypass android -alias androiddebugkey -keyalg RSA -keysize 2048 \
    -validity 10000 -dname 'CN=Android Debug,O=Android,C=US'
fi
"$sdk_tools/apksigner" sign --ks "$project_dir/tools/debug.keystore" --ks-pass pass:android \
  --key-pass pass:android --out "$build_dir/MoiZadachi-v1.5.apk" "$build_dir/aligned.apk"
"$sdk_tools/apksigner" verify --verbose "$build_dir/MoiZadachi-v1.5.apk"
echo "Built $build_dir/MoiZadachi-v1.5.apk"
