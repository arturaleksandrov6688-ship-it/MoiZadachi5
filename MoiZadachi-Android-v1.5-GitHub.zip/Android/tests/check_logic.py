from pathlib import Path
import os,re,sqlite3,subprocess,tempfile
root=Path(__file__).resolve().parents[1];src=root/'app/src/main/java/ru/moizadachi/app'
s=(src/'TaskDb.java').read_text()
create=re.search(r'execSQL\("(CREATE TABLE[^\"]+)',s)[1]
alter=re.search(r'execSQL\("(ALTER TABLE[^\"]+)',s)[1]
order=re.search(r'"(done ASC,CASE[^\"]+)"',s)[1]
db=sqlite3.connect(':memory:');db.execute(create)
for title,due,done,cat in [('Дом без даты',0,0,'home'),('Работа в срок',2000,0,'work'),('Готово',1000,1,'home'),('Дом в срок',1500,0,'home')]:
 db.execute('INSERT INTO tasks(title,due_at,done,category) VALUES(?,?,?,?)',(title,due,done,cat))
assert [x[0] for x in db.execute('SELECT title FROM tasks ORDER BY '+order)]==['Дом в срок','Работа в срок','Дом без даты','Готово']
assert db.execute('SELECT count(*) FROM tasks WHERE due_at>=? AND due_at<?',(1000,3000)).fetchone()[0]==3
assert db.execute("SELECT count(*) FROM tasks WHERE category='work' AND done=0").fetchone()[0]==1
old=sqlite3.connect(':memory:');old.execute(create.replace(",category TEXT NOT NULL DEFAULT 'home'",''));old.execute("INSERT INTO tasks(title,note,due_at,photo_uri) VALUES('Старое','Текст',3000,'content://photo/1')");old.execute(alter)
assert old.execute('SELECT title,note,due_at,photo_uri,category FROM tasks').fetchone()==('Старое','Текст',3000,'content://photo/1','home')
# Exercise the v2 -> v3 migration with existing photos and an undated task.
import uuid
cloud_defs=re.search(r'for\(String def:new String\[\]\{([^}]+)',s)[1]
for definition in re.findall(r'"([^"\n]+)"',cloud_defs):
 old.execute('ALTER TABLE tasks ADD COLUMN '+definition)
for (task_id,) in old.execute('SELECT id FROM tasks').fetchall():
 old.execute('UPDATE tasks SET uuid=? WHERE id=?',(str(uuid.uuid4()),task_id))
old.execute('UPDATE tasks SET photo_dirty=1 WHERE photo_uri IS NOT NULL')
old.execute('CREATE UNIQUE INDEX tasks_uuid ON tasks(uuid)')
assert old.execute('SELECT title,owner,dirty,photo_dirty,server_version FROM tasks').fetchone()==('Старое','',1,1,0)
old.execute("UPDATE tasks SET owner='account-a',dirty=1 WHERE owner=''")
assert old.execute("SELECT title,photo_uri FROM tasks WHERE owner='account-a'").fetchone()==('Старое','content://photo/1')
assert old.execute("SELECT count(*) FROM tasks WHERE owner=''").fetchone()[0]==0
print('Cloud migration: existing task/photo preserved, UUID assigned, local tasks adopted')
print('SQLite: optional dates, sorting, calendar query, categories, non-destructive schema migration passed')
stubs={
 'android/os/Build.java':'package android.os; public class Build { public static class VERSION { public static int SDK_INT=35; }}',
 'android/content/Context.java':'''package android.content; public class Context { public static final String ALARM_SERVICE="alarm"; public android.app.AlarmManager alarms=new android.app.AlarmManager();public Object getSystemService(String s){return alarms;} public <T>T getSystemService(Class<T> t){return null;}}''',
 'android/content/Intent.java':'''package android.content; public class Intent { public boolean early; public Intent(Context c,Class<?> cl){}public Intent putExtra(String k,long v){return this;}public Intent putExtra(String k,boolean v){early=v;return this;}}''',
 'android/app/PendingIntent.java':'''package android.app; public class PendingIntent {public static final int FLAG_UPDATE_CURRENT=1,FLAG_IMMUTABLE=2; public boolean early;public static PendingIntent getBroadcast(android.content.Context c,int id,android.content.Intent i,int flags){PendingIntent p=new PendingIntent();p.early=i.early;return p;}}''',
 'android/app/AlarmManager.java':'''package android.app; public class AlarmManager {public static final int RTC_WAKEUP=0;public int cancels,exact,inexact;public boolean allowed=true;public java.util.List<Long> times=new java.util.ArrayList<>();public void cancel(PendingIntent p){cancels++;}public boolean canScheduleExactAlarms(){return allowed;}public void setExactAndAllowWhileIdle(int t,long at,PendingIntent p){exact++;times.add(at);}public void setAndAllowWhileIdle(int t,long at,PendingIntent p){inexact++;times.add(at);}public void set(int t,long at,PendingIntent p){inexact++;times.add(at);}}''',
 'android/app/NotificationChannel.java':'package android.app; public class NotificationChannel {public NotificationChannel(String a,String b,int c){}}',
 'android/app/NotificationManager.java':'package android.app; public class NotificationManager {public static final int IMPORTANCE_HIGH=1;public void createNotificationChannel(NotificationChannel c){}}',
 'ru/moizadachi/app/ReminderReceiver.java':'package ru.moizadachi.app; public class ReminderReceiver {}',
 'ru/moizadachi/app/Check.java':'''package ru.moizadachi.app;
import android.content.Context;
public class Check {
 static void check(boolean ok){if(!ok)throw new AssertionError();}
 public static void main(String[] args){
 long now=System.currentTimeMillis();Task t=new Task();t.id=7;Context c=new Context();
 ReminderScheduler.schedule(c,t);check(c.alarms.cancels==2&&c.alarms.times.isEmpty());
 t.dueAt=now+86400000;t.remindBefore=18000000;c=new Context();ReminderScheduler.schedule(c,t);check(c.alarms.times.size()==2&&c.alarms.times.contains(t.dueAt)&&c.alarms.times.contains(t.dueAt-t.remindBefore));
 t.done=true;c=new Context();ReminderScheduler.schedule(c,t);check(c.alarms.cancels==2&&c.alarms.times.isEmpty());
 t.done=false;t.dueAt=0;c=new Context();ReminderScheduler.schedule(c,t);check(c.alarms.cancels==2&&c.alarms.times.isEmpty());
 t.dueAt=now-1000;c=new Context();ReminderScheduler.schedule(c,t);check(c.alarms.times.isEmpty());
 t.dueAt=now+100000;t.remindBefore=36000000;c=new Context();ReminderScheduler.schedule(c,t);check(c.alarms.times.size()==1);
 t.remindBefore=0;c=new Context();c.alarms.allowed=false;ReminderScheduler.schedule(c,t);check(c.alarms.inexact==1);
 android.os.Build.VERSION.SDK_INT=26;c=new Context();c.alarms.allowed=false;ReminderScheduler.schedule(c,t);check(c.alarms.exact==1);
 System.out.println("Reminder scheduler: undated/completed/overdue cancellation, due and early alarms, fallback and Android 8 passed");
 }
}'''
}
with tempfile.TemporaryDirectory() as tmp:
 d=Path(tmp)
 for path,text in stubs.items():
  f=d/path;f.parent.mkdir(parents=True,exist_ok=True);f.write_text(text)
 for name in ['Task.java','ReminderScheduler.java']:(d/'ru/moizadachi/app'/name).write_text((src/name).read_text())
 java=Path(os.environ['JAVA_HOME'])/'bin'
 subprocess.run([str(java/'javac'),'-encoding','UTF-8','-d',str(d/'classes')]+[str(x) for x in d.rglob('*.java')],check=True)
 subprocess.run([str(java/'java'),'-cp',str(d/'classes'),'ru.moizadachi.app.Check'],check=True)
