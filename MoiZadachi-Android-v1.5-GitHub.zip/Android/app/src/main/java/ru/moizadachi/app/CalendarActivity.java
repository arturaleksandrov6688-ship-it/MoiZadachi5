package ru.moizadachi.app;
import android.app.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.*;
import android.widget.*;
import java.text.*;
import java.util.*;
public class CalendarActivity extends Activity {
 private final Calendar month=Calendar.getInstance(),selected=Calendar.getInstance();private TaskDb db;private GridLayout grid;private TextView heading;private LinearLayout dayTasks;private String filter;private final Locale ru=new Locale("ru");
 public void onCreate(Bundle b){ThemeUtil.apply(this);super.onCreate(b);db=new TaskDb(this);filter=getIntent().getStringExtra("category");if(filter==null)filter="all";if(b!=null){month.setTimeInMillis(b.getLong("month"));selected.setTimeInMillis(b.getLong("selected"));}month.set(Calendar.DAY_OF_MONTH,1);draw();}
 protected void onSaveInstanceState(Bundle b){b.putLong("month",month.getTimeInMillis());b.putLong("selected",selected.getTimeInMillis());super.onSaveInstanceState(b);}
 protected void onResume(){super.onResume();if(grid!=null){renderMonth();showDay(selected);}}
 private void draw(){LinearLayout root=Ui.column(this);Button back=Ui.button(this,"‹  К задачам");back.setOnClickListener(v->finish());root.addView(back);
  LinearLayout nav=new LinearLayout(this);nav.setGravity(Gravity.CENTER);Button prev=Ui.button(this,"‹");prev.setContentDescription("Предыдущий месяц");prev.setOnClickListener(v->{month.add(Calendar.MONTH,-1);renderMonth();});nav.addView(prev,new LinearLayout.LayoutParams(Ui.dp(this,48),-2));heading=Ui.text(this,"",20);heading.setGravity(Gravity.CENTER);nav.addView(heading,new LinearLayout.LayoutParams(0,-2,1));Button next=Ui.button(this,"›");next.setContentDescription("Следующий месяц");next.setOnClickListener(v->{month.add(Calendar.MONTH,1);renderMonth();});nav.addView(next,new LinearLayout.LayoutParams(Ui.dp(this,48),-2));root.addView(nav);
  root.addView(Ui.text(this,"Раздел: "+("home".equals(filter)?"Дом":"work".equals(filter)?"Работа":"Все"),14));grid=new GridLayout(this);grid.setColumnCount(7);root.addView(grid);
  ScrollView scroll=new ScrollView(this);dayTasks=new LinearLayout(this);dayTasks.setOrientation(1);scroll.addView(dayTasks);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));Ui.install(this,root);
 }
 private List<Task> tasks(Calendar c){List<Task> out=new ArrayList<>();Calendar end=(Calendar)c.clone();end.add(Calendar.DAY_OF_MONTH,1);for(Task t:db.between(start(c),start(end)))if("all".equals(filter)||filter.equals(t.category))out.add(t);return out;}
 private void renderMonth(){grid.removeAllViews();heading.setText(new SimpleDateFormat("LLLL yyyy",ru).format(month.getTime()));for(String n:new String[]{"Пн","Вт","Ср","Чт","Пт","Сб","Вс"})addCell(n,false,false,null);int blank=(month.get(Calendar.DAY_OF_WEEK)+5)%7;for(int i=0;i<blank;i++)addCell("",false,false,null);for(int d=1;d<=month.getActualMaximum(Calendar.DAY_OF_MONTH);d++){Calendar day=(Calendar)month.clone();day.set(Calendar.DAY_OF_MONTH,d);boolean marked=!tasks(day).isEmpty();addCell(String.valueOf(d),marked,start(day)==start(selected),v->{selected.setTimeInMillis(day.getTimeInMillis());renderMonth();showDay(selected);});}}
 private void addCell(String text,boolean marked,boolean chosen,View.OnClickListener click){TextView v=Ui.text(this,text,15);v.setGravity(Gravity.CENTER);v.setMinHeight(Ui.dp(this,44));GridLayout.LayoutParams lp=new GridLayout.LayoutParams();lp.width=0;lp.columnSpec=GridLayout.spec(GridLayout.UNDEFINED,1f);lp.setMargins(2,2,2,2);if(marked||chosen){GradientDrawable bg=new GradientDrawable();bg.setCornerRadius(Ui.dp(this,12));bg.setColor(marked?(Ui.dark(this)?0xff334c66:0xffdce8f4):Color.TRANSPARENT);if(chosen)bg.setStroke(Ui.dp(this,2),Ui.dark(this)?0xff9abde0:0xff456b96);v.setBackground(bg);}if(click!=null){v.setOnClickListener(click);v.setContentDescription(text+(marked?", есть задачи":""));}grid.addView(v,lp);}
 private void showDay(Calendar c){dayTasks.removeAllViews();TextView label=Ui.text(this,new SimpleDateFormat("d MMMM",ru).format(c.getTime()),20);label.setPadding(0,Ui.dp(this,16),0,Ui.dp(this,12));dayTasks.addView(label);List<Task> items=tasks(c);if(items.isEmpty())dayTasks.addView(Ui.text(this,"На этот день задач нет",16));for(Task t:items){TextView row=Ui.text(this,(t.done?"✓  ":"")+new SimpleDateFormat("HH:mm",ru).format(new Date(t.dueAt))+"  ·  "+t.categoryLabel()+"\n"+t.title,17);row.setBackground(Ui.card(this,t.category));int pad=Ui.dp(this,12);row.setPadding(pad,pad,pad,pad);row.setOnClickListener(v->startActivity(new Intent(this,TaskViewActivity.class).putExtra("id",t.id)));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.bottomMargin=Ui.dp(this,8);dayTasks.addView(row,lp);}}
 private long start(Calendar c){Calendar x=(Calendar)c.clone();x.set(Calendar.HOUR_OF_DAY,0);x.set(Calendar.MINUTE,0);x.set(Calendar.SECOND,0);x.set(Calendar.MILLISECOND,0);return x.getTimeInMillis();}
}
