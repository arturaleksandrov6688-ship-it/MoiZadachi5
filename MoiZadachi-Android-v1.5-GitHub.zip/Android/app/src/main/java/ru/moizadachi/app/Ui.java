package ru.moizadachi.app;
import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.view.*;
import android.widget.*;
final class Ui {
 static int dp(Context c,int n){return Math.round(n*c.getResources().getDisplayMetrics().density);}
 static boolean dark(Context c){android.util.TypedValue v=new android.util.TypedValue();c.getTheme().resolveAttribute(android.R.attr.isLightTheme,v,true);return v.data==0;}
 static TextView text(Context c,String s,int sp){TextView v=new TextView(c);v.setText(s);v.setTextSize(sp);v.setTextColor(dark(c)?0xffe5e9ef:0xff253343);v.setLineSpacing(dp(c,3),1);return v;}
 static Button button(Context c,String s){Button b=new Button(c);b.setText(s);b.setAllCaps(false);b.setMinHeight(dp(c,48));return b;}
 static LinearLayout column(Context c){LinearLayout l=new LinearLayout(c);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(dp(c,20),dp(c,16),dp(c,20),dp(c,16));return l;}
 static void install(Activity a,View root){
  int bg=dark(a)?0xff171d26:0xfff7f8fa;root.setBackgroundColor(bg);
  if(Build.VERSION.SDK_INT>=30){
   a.getWindow().setDecorFitsSystemWindows(false);
   root.setOnApplyWindowInsetsListener((v,w)->{android.graphics.Insets in=w.getInsets(WindowInsets.Type.systemBars()|WindowInsets.Type.displayCutout()|WindowInsets.Type.ime());v.setPadding(dp(a,20)+in.left,dp(a,12)+in.top,dp(a,12)+in.right,dp(a,12)+in.bottom);return w;});
  }else{a.getWindow().getDecorView().setSystemUiVisibility(dark(a)?0:View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);a.getWindow().setStatusBarColor(bg);a.getWindow().setNavigationBarColor(bg);}
  a.setContentView(root);root.requestApplyInsets();
  if(Build.VERSION.SDK_INT>=30&&a.getWindow().getInsetsController()!=null)a.getWindow().getInsetsController().setSystemBarsAppearance(dark(a)?0:WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS|WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS,WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS|WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS);
 }
 static GradientDrawable card(Context c,String category){GradientDrawable d=new GradientDrawable();boolean work="work".equals(category);d.setColor(dark(c)?(work?0xff283247:0xff263a35):(work?0xffe9edf6:0xffe8f1eb));d.setCornerRadius(dp(c,16));return d;}
 static void openPhoto(Activity a,String uri){a.startActivity(new android.content.Intent(a,PhotoActivity.class).putExtra("uri",uri));}
}
