package ru.moizadachi.app;
final class Task {
 long id,dueAt,remindBefore,serverVersion,revision=1;
 String title="",note="",photoUri,uuid="",owner="",photoPath;
 boolean done,deleted,photoDirty,conflict,dirty=true;
 String category="home";
 String categoryLabel(){return "work".equals(category)?"Работа":"Дом";}
}
