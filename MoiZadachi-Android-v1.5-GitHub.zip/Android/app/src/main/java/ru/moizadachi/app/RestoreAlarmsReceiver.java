package ru.moizadachi.app;
import android.content.*;
public class RestoreAlarmsReceiver extends BroadcastReceiver {
 public void onReceive(Context c,Intent i){SyncJobs.setup(c);SyncJobs.request(c);try(TaskDb db=new TaskDb(c)){for(Task t:db.all())ReminderScheduler.schedule(c,t);}}
}
