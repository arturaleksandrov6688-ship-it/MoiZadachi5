package ru.moizadachi.app;

import android.app.*;
import android.content.*;

final class ReminderScheduler {
    static void createChannel(Context c){NotificationChannel channel=new NotificationChannel("tasks","Напоминания о задачах",NotificationManager.IMPORTANCE_HIGH);c.getSystemService(NotificationManager.class).createNotificationChannel(channel);}

    private static PendingIntent intent(Context c,long id,boolean early){return intent(c,id,early,0);}
    static PendingIntent intent(Context c,long id,boolean early,long offset){
        Intent i=new Intent(c,ReminderReceiver.class).putExtra("id",id).putExtra("early",early);
        int code=(int)(id*100+(early?(offset/900000L)%99+1:0));return PendingIntent.getBroadcast(c,code,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
    }
    static void schedule(Context c,Task t){
        cancel(c,t.id);if(t.done||t.dueAt<=System.currentTimeMillis())return;AlarmManager a=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
        set(a,t.dueAt,intent(c,t.id,false));for(long offset:ReminderCodec.offsets(t.remindBefore))if(t.dueAt-offset>System.currentTimeMillis())set(a,t.dueAt-offset,intent(c,t.id,true,offset));
    }
    private static void set(AlarmManager a,long at,PendingIntent p){
        try{if(android.os.Build.VERSION.SDK_INT<31||a.canScheduleExactAlarms())a.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,at,p);else a.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,at,p);}catch(SecurityException e){a.set(AlarmManager.RTC_WAKEUP,at,p);}
    }
    static void cancel(Context c,long id){AlarmManager a=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);a.cancel(intent(c,id,false));for(long offset:ReminderCodec.OFFSETS)a.cancel(intent(c,id,true,offset));}
}
