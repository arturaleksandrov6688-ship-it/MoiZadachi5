package ru.moizadachi.app;
import android.app.job.*;
public class SyncJobService extends JobService {
 public boolean onStartJob(JobParameters p){new Thread(()->{CloudSync.run(this);boolean retry;try(TaskDb db=new TaskDb(this)){retry=!CloudAuth.owner(this).isEmpty()&&db.pending()>0;}jobFinished(p,retry);},"cloud-sync").start();return true;}
 public boolean onStopJob(JobParameters p){return true;}
}
