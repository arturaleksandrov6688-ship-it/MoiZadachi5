package ru.moizadachi.app;
import android.app.job.*;
import android.content.*;
final class SyncJobs {
 static void setup(Context c){if(CloudAuth.owner(c).isEmpty())return;JobScheduler s=c.getSystemService(JobScheduler.class);s.schedule(new JobInfo.Builder(701,new ComponentName(c,SyncJobService.class)).setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY).setPeriodic(15*60*1000L).setPersisted(true).build());}
 static void request(Context c){if(CloudAuth.owner(c).isEmpty())return;c.getSystemService(JobScheduler.class).schedule(new JobInfo.Builder(702,new ComponentName(c,SyncJobService.class)).setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY).setMinimumLatency(1500).setBackoffCriteria(30000,JobInfo.BACKOFF_POLICY_EXPONENTIAL).build());}
 static void cancel(Context c){JobScheduler s=c.getSystemService(JobScheduler.class);s.cancel(701);s.cancel(702);}
}
