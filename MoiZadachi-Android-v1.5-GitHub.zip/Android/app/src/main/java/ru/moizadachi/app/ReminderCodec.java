package ru.moizadachi.app;
import java.util.*;
final class ReminderCodec {
 static final long MARK=1000000000000000L;
 static final long[] OFFSETS={900000L,3600000L,18000000L,36000000L,86400000L,129600000L,172800000L};
 static long encode(boolean[] selected){long mask=0;for(int i=0;i<selected.length&&i<OFFSETS.length;i++)if(selected[i])mask|=1L<<i;return mask==0?0:MARK+mask;}
 static boolean[] decode(long value){boolean[] out=new boolean[OFFSETS.length];if(value>=MARK){long mask=value-MARK;for(int i=0;i<out.length;i++)out[i]=(mask&(1L<<i))!=0;}else if(value>0){for(int i=0;i<out.length;i++)if(OFFSETS[i]==value)out[i]=true;}return out;}
 static long[] offsets(long value){boolean[] b=decode(value);ArrayList<Long> a=new ArrayList<>();for(int i=0;i<b.length;i++)if(b[i])a.add(OFFSETS[i]);long[] r=new long[a.size()];for(int i=0;i<r.length;i++)r[i]=a.get(i);return r;}
}
