package ru.moizadachi.app;
import android.content.*;
import android.security.keystore.*;
import android.util.Base64;
import java.security.*;
import javax.crypto.*;
import javax.crypto.spec.GCMParameterSpec;
import org.json.*;
final class CloudAuth {
 static final String URL="https://otyirhginvoojpejuufp.supabase.co";
 static final String KEY="sb_publishable_ILgSvULsR5X8bt-0kDKPuA_X2D4jf2y";
 static SharedPreferences prefs(Context c){return c.getSharedPreferences("cloud",0);}
 static String owner(Context c){return prefs(c).getString("owner","");}
 static String email(Context c){return prefs(c).getString("email","");}
 static SecretKey key() throws Exception {KeyStore k=KeyStore.getInstance("AndroidKeyStore");k.load(null);if(!k.containsAlias("moi-cloud-session")){KeyGenerator g=KeyGenerator.getInstance("AES","AndroidKeyStore");g.init(new KeyGenParameterSpec.Builder("moi-cloud-session",KeyProperties.PURPOSE_ENCRYPT|KeyProperties.PURPOSE_DECRYPT).setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build());g.generateKey();}return (SecretKey)k.getKey("moi-cloud-session",null);}
 static synchronized JSONObject session(Context c) throws Exception {String s=prefs(c).getString("session","");if(s.isEmpty())return null;try{String[] a=s.split(":");Cipher x=Cipher.getInstance("AES/GCM/NoPadding");x.init(Cipher.DECRYPT_MODE,key(),new GCMParameterSpec(128,Base64.decode(a[0],2)));return new JSONObject(new String(x.doFinal(Base64.decode(a[1],2)),"UTF-8"));}catch(Exception e){throw new Exception("Войдите в аккаунт заново. Локальные задачи сохранены.");}}
 static synchronized void save(Context c,JSONObject s) throws Exception {if(!s.has("expires_at"))s.put("expires_at",System.currentTimeMillis()/1000+s.optLong("expires_in",3600));Cipher x=Cipher.getInstance("AES/GCM/NoPadding");x.init(Cipher.ENCRYPT_MODE,key());String value=Base64.encodeToString(x.getIV(),2)+":"+Base64.encodeToString(x.doFinal(s.toString().getBytes("UTF-8")),2);JSONObject u=s.getJSONObject("user");if(!prefs(c).edit().putString("session",value).putString("owner",u.getString("id")).putString("email",u.optString("email","")).commit())throw new Exception("Не удалось сохранить вход на устройстве");}
 static synchronized String token(Context c) throws Exception {JSONObject s=session(c);if(s==null)throw new Exception("Войдите в аккаунт");if(s.optLong("expires_at")<System.currentTimeMillis()/1000+90){JSONObject body=new JSONObject().put("refresh_token",s.getString("refresh_token"));s=new JSONObject(CloudSync.request("POST","/auth/v1/token?grant_type=refresh_token",null,body.toString().getBytes("UTF-8"),"application/json",null));save(c,s);}return s.getString("access_token");}
 static void logout(Context c){try(TaskDb db=new TaskDb(c)){for(Task t:db.all())ReminderScheduler.cancel(c,t.id);}prefs(c).edit().remove("session").remove("owner").remove("email").remove("last_sync").commit();SyncJobs.cancel(c);}
}
