package ru.moizadachi.app;
import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.*;
import android.widget.*;
import java.text.*;
import java.util.*;
public class MainActivity extends Activity {
 private final SimpleDateFormat fmt=new SimpleDateFormat("d MMMM, HH:mm",new Locale("ru"));
 private Button syncStatus,sendCloud; private final android.os.Handler syncHandler=new android.os.Handler(android.os.Looper.getMainLooper()); private final Runnable syncLoop=new Runnable(){public void run(){new Thread(()->CloudSync.run(MainActivity.this)).start();syncHandler.postDelayed(this,45000);}}; private final BroadcastReceiver updates=new BroadcastReceiver(){public void onReceive(Context c,Intent i){reload();}};
 private TaskDb db;private LinearLayout list;private String filter="all";private boolean completed=false;private Button[] tabs=new Button[3];
 public void onCreate(Bundle b){ThemeUtil.apply(this);super.onCreate(b);db=new TaskDb(this);ReminderScheduler.createChannel(this);if(b!=null){filter=b.getString("filter","all");completed=b.getBoolean("completed");}requestNotifications();draw();}
 protected void onSaveInstanceState(Bundle b){b.putString("filter",filter);b.putBoolean("completed",completed);super.onSaveInstanceState(b);}
 protected void onResume(){super.onResume();if(list!=null)reload();for(Task t:db.all())ReminderScheduler.schedule(this,t);IntentFilter f=new IntentFilter(getPackageName()+".SYNC");if(android.os.Build.VERSION.SDK_INT>=33)registerReceiver(updates,f,Context.RECEIVER_NOT_EXPORTED);else registerReceiver(updates,f);SyncJobs.setup(this);syncHandler.post(syncLoop);}
 protected void onPause(){super.onPause();syncHandler.removeCallbacks(syncLoop);try{unregisterReceiver(updates);}catch(Exception ignored){}}
 private void draw(){
  LinearLayout root=Ui.column(this),bar=new LinearLayout(this);bar.setGravity(Gravity.CENTER_VERTICAL);
  TextView title=Ui.text(this,"Мои задачи",26);title.setTypeface(null,1);bar.addView(title,new LinearLayout.LayoutParams(0,-2,1));
  Button menu=Ui.button(this,"⋯");menu.setContentDescription("Настройки и календарь");menu.setOnClickListener(v->{new AlertDialog.Builder(this).setItems(new String[]{"Календарь",ThemeUtil.label(this),"О разделах","Точность напоминаний"},(d,n)->{if(n==0)startActivity(new Intent(this,CalendarActivity.class).putExtra("category",filter));else if(n==1)ThemeUtil.next(this);else if(n==3){if(android.os.Build.VERSION.SDK_INT>=31&&!getSystemService(AlarmManager.class).canScheduleExactAlarms()){try{startActivity(new Intent(android.provider.Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,android.net.Uri.parse("package:"+getPackageName())));}catch(Exception e){Toast.makeText(this,"Откройте разрешения приложения в настройках телефона",Toast.LENGTH_LONG).show();}}else Toast.makeText(this,"Точные напоминания разрешены",Toast.LENGTH_SHORT).show();}else new AlertDialog.Builder(this).setTitle("Дом и работа").setMessage("При запуске показаны все задачи. Выберите раздел, чтобы оставить только домашние или рабочие.\n\nВыполненные хранятся в отдельном списке до ручного удаления.\n\nЗадачи без даты не появляются в календаре и не присылают напоминаний.").setPositiveButton("Понятно",null).show();}).show();});bar.addView(menu,new LinearLayout.LayoutParams(Ui.dp(this,56),-2));root.addView(bar);
  LinearLayout filters=new LinearLayout(this);String[] labels={"Все","Дом","Работа"},values={"all","home","work"};
  for(int i=0;i<3;i++){final String cat=values[i];Button b=Ui.button(this,labels[i]);tabs[i]=b;b.setOnClickListener(v->{filter=cat;reload();});filters.addView(b,new LinearLayout.LayoutParams(0,-2,1));}root.addView(filters);syncStatus=Ui.button(this,"Аккаунт и синхронизация");syncStatus.setTextSize(13);syncStatus.setOnClickListener(v->startActivity(new Intent(this,AccountActivity.class)));root.addView(syncStatus);sendCloud=Ui.button(this,"Отправить в облако");sendCloud.setOnClickListener(v->{if(CloudAuth.owner(this).isEmpty()){Toast.makeText(this,"Войдите, чтобы отправить местные задачи в облако",Toast.LENGTH_LONG).show();startActivity(new Intent(this,AccountActivity.class));return;}if(CloudSync.BUSY.get()){Toast.makeText(this,"Синхронизация уже идёт",Toast.LENGTH_SHORT).show();return;}sendCloud.setEnabled(false);sendCloud.setText("Отправка…");new Thread(()->{CloudSync.run(getApplicationContext());runOnUiThread(()->{if(isFinishing()||isDestroyed())return;reload();Toast.makeText(this,CloudSync.status,Toast.LENGTH_LONG).show();});},"manual-cloud-sync").start();});root.addView(sendCloud);
  ScrollView scroll=new ScrollView(this);list=new LinearLayout(this);list.setOrientation(1);scroll.addView(list);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
  Button add=Ui.button(this,"＋  Новая задача");add.setOnClickListener(v->startActivity(new Intent(this,EditTaskActivity.class).putExtra("category","work".equals(filter)?"work":"home")));root.addView(add);Ui.install(this,root);
 }
 private void reload(){
  if(syncStatus!=null)syncStatus.setText(CloudAuth.owner(this).isEmpty()?"Войти · подключить облако":(CloudSync.BUSY.get()?"Синхронизация…":CloudAuth.prefs(this).getString("status","Облако"))+" · ожидают: "+db.pending());
  if(sendCloud!=null){sendCloud.setEnabled(!CloudSync.BUSY.get());sendCloud.setText(CloudSync.BUSY.get()?"Отправка…":"Отправить в облако");}
  list.removeAllViews();String[] cats={"all","home","work"};for(int i=0;i<3;i++){boolean active=cats[i].equals(filter);tabs[i].setTypeface(null,active?1:0);tabs[i].setAlpha(active?1f:.65f);tabs[i].setContentDescription(tabs[i].getText()+(active?", выбран":""));}
  List<Task> active=new ArrayList<>(),done=new ArrayList<>();for(Task t:db.all())if("all".equals(filter)||filter.equals(t.category)){(t.done?done:active).add(t);}
  TextView summary=Ui.text(this,"Активные: "+active.size(),14);summary.setPadding(0,Ui.dp(this,8),0,Ui.dp(this,12));list.addView(summary);
  if(active.isEmpty()){TextView empty=Ui.text(this,"Здесь пока нет активных задач",18);empty.setPadding(0,Ui.dp(this,28),0,Ui.dp(this,28));list.addView(empty);}
  for(Task t:active)addRow(t);
  if(!done.isEmpty()){Button b=Ui.button(this,(completed?"▾":"▸")+"  Выполненные · "+done.size());b.setOnClickListener(v->{completed=!completed;reload();});list.addView(b);if(completed){list.addView(Ui.text(this,"Сохраняются до удаления. Галочка возвращает задачу в активные.",13));for(Task t:done)addRow(t);}}
 }
 private void addRow(Task t){
  LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);int pad=Ui.dp(this,10);row.setPadding(pad,pad,pad,pad);row.setBackground(Ui.card(this,t.category));
  CheckBox check=new CheckBox(this);check.setChecked(t.done);check.setContentDescription((t.done?"Вернуть в активные: ":"Выполнить: ")+t.title);check.setOnCheckedChangeListener((b,on)->{t.done=on;db.setDone(t.id,on);ReminderScheduler.schedule(this,t);reload();});row.addView(check);
  LinearLayout words=new LinearLayout(this);words.setOrientation(1);TextView name=Ui.text(this,t.title,18);if(t.done)name.setPaintFlags(name.getPaintFlags()|16);words.addView(name);
  String meta=(t.conflict?"Разные версии · ":"")+t.categoryLabel()+(t.dueAt==0?"":"  ·  "+fmt.format(new Date(t.dueAt)))+(t.photoUri==null&&t.photoPath==null?"":"  ·  Фото");words.addView(Ui.text(this,meta,13));row.addView(words,new LinearLayout.LayoutParams(0,-2,1));row.setOnClickListener(v->startActivity(new Intent(this,TaskViewActivity.class).putExtra("id",t.id)));
  LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.bottomMargin=Ui.dp(this,10);list.addView(row,lp);
 }
 private void requestNotifications(){if(android.os.Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},50);}
}
