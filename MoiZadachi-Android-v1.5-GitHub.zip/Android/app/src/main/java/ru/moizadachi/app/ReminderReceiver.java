package ru.moizadachi.app;

import android.app.*;
import android.content.*;

public class ReminderReceiver extends BroadcastReceiver {
    public void onReceive(Context c,Intent i){
        ReminderScheduler.createChannel(c);
        long id=i.getLongExtra("id",0);Task t=new TaskDb(c).get(id);if(t==null||t.done||t.dueAt==0)return;
        Intent open=new Intent(c,TaskViewActivity.class).putExtra("id",id);PendingIntent pi=PendingIntent.getActivity(c,(int)id,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        String text=i.getBooleanExtra("early",false)?"Скоро срок выполнения":"Срок выполнения наступил";
        Notification n=new Notification.Builder(c,"tasks").setSmallIcon(android.R.drawable.ic_popup_reminder).setContentTitle(t.title).setContentText(text).setAutoCancel(true).setContentIntent(pi).build();
        ((NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE)).notify((int)(id*2+(i.getBooleanExtra("early",false)?1:0)),n);
    }
}
