package ru.moizadachi.app;
import android.app.*;
import android.content.*;
import android.os.Bundle;
import android.widget.*;
import java.text.*;
import java.util.*;
public class TaskViewActivity extends Activity {
 private TaskDb db;
 public void onCreate(Bundle b){ThemeUtil.apply(this);super.onCreate(b);db=new TaskDb(this);}
 protected void onResume(){super.onResume();draw();}
 private void draw(){
  Task t=db.get(getIntent().getLongExtra("id",0));if(t==null){finish();return;}
  LinearLayout root=Ui.column(this),bar=new LinearLayout(this);Button back=Ui.button(this,"‹ Назад");back.setOnClickListener(v->finish());bar.addView(back,new LinearLayout.LayoutParams(0,-2,1));Button edit=Ui.button(this,"Редактировать");edit.setOnClickListener(v->startActivity(new Intent(this,EditTaskActivity.class).putExtra("id",t.id)));bar.addView(edit,new LinearLayout.LayoutParams(0,-2,1));root.addView(bar);
  ScrollView scroll=new ScrollView(this);LinearLayout content=Ui.column(this);content.setPadding(0,Ui.dp(this,24),0,Ui.dp(this,24));TextView title=Ui.text(this,t.title,28);title.setTypeface(null,1);title.setTextIsSelectable(true);content.addView(title);
  if(t.dueAt>0){TextView date=Ui.text(this,new SimpleDateFormat("d MMMM yyyy, HH:mm",new Locale("ru")).format(new Date(t.dueAt)),16);date.setPadding(0,Ui.dp(this,16),0,0);content.addView(date);}
  if(t.note!=null&&!t.note.isEmpty()){TextView note=Ui.text(this,t.note,19);note.setTextIsSelectable(true);note.setPadding(0,Ui.dp(this,24),0,0);content.addView(note);}
  if(t.photoUri!=null||t.photoPath!=null){Button photo=Ui.button(this,"Открыть прикреплённое фото");photo.setOnClickListener(v->{if(t.photoUri!=null)Ui.openPhoto(this,t.photoUri);else Toast.makeText(this,"Фото загрузится после синхронизации",Toast.LENGTH_LONG).show();});content.addView(photo);}
  scroll.addView(content);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));Ui.install(this,root);
 }
}
