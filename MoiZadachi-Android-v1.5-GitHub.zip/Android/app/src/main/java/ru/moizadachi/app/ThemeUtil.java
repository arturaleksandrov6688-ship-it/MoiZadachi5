package ru.moizadachi.app;
import android.app.Activity;
final class ThemeUtil {
 static void apply(Activity a){int mode=a.getSharedPreferences("settings",0).getInt("theme",0);boolean night=(a.getResources().getConfiguration().uiMode&48)==32;a.setTheme(mode==2||(mode==0&&night)?R.style.AppThemeDark:R.style.AppThemeLight);}
 static String label(Activity a){int m=a.getSharedPreferences("settings",0).getInt("theme",0);return m==0?"Тема: как в системе":m==1?"Тема: светлая":"Тема: тёмная";}
 static void next(Activity a){int m=a.getSharedPreferences("settings",0).getInt("theme",0);a.getSharedPreferences("settings",0).edit().putInt("theme",(m+1)%3).apply();a.recreate();}
}
